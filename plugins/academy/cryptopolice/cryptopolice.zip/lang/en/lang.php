<?php return [
    'plugin' => [
        'name' => 'Cunami',
        'description' => ''
    ]
];